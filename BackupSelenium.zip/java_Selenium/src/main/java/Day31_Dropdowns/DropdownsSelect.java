package Day31_Dropdowns;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DropdownsSelect {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://phppot.com/demo/jquery-dependent-dropdown-list-countries-and-states/");
		//driver.findElement(By.xpath("//div[@class=\"content\"]/a[@title=\"Helping you build websites\"]")).click();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		
		driver.manage().window().maximize();
		
		WebElement dropC = driver.findElement(By.xpath("//select[@name=\"country\"]"));
		WebElement dropS = driver.findElement(By.xpath("//select[@name=\"state\"]"));
		
		Select dropCountry = new Select(dropC);
		
        List<WebElement> options = dropCountry.getOptions();
        
        System.out.println("Size of the dropdown:"+ options.size());
        
        for(WebElement x: options)
        {
        	System.out.println(x.getText());
        	
        	
        }
        
        
       dropCountry.selectByContainsVisibleText("China");        
		
	  // dropS.click();
       wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath("//select[@name=\"state\"]/option"), 1));
      
       Select dropState = new Select(dropS);
		
       List<WebElement> optionss = dropState.getOptions();
       
       System.out.println("Size of the dropdown:"+ optionss.size());
       
       for(WebElement c: optionss)
       {
       	System.out.println(c.getText());
       	
       	
       }
       
       
      dropState.selectByContainsVisibleText("Hebei");        
		
		
		
		
		
		

	}

}
