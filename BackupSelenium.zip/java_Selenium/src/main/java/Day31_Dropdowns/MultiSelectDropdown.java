package Day31_Dropdowns;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class MultiSelectDropdown {

	public static void main(String[] args) {

		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		Select drop = new Select(driver.findElement(By.xpath("//select[@id=\"colors\"]")));
		
		List<WebElement> options = drop.getOptions();
		
		System.out.println("values of the color dropdown: "+options.size());
		
		drop.selectByValue("red");
		
		drop.selectByValue("blue");
		
		drop.selectByValue("white");
		
Select dropAnimal = new Select(driver.findElement(By.xpath("//select[@id=\"animals\"]")));
		
		List<WebElement> optionsAn = dropAnimal.getOptions();
		
		System.out.println("values of the Animals dropdown: "+optionsAn.size());
		
		for(int i=0;i<optionsAn.size();i++)
		{
			optionsAn.get(i).click();
		}
		
		
		
		
		
		
	}

}
