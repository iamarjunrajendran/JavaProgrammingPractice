package Day31_Dropdowns;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HiddenDropdownSelection {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new EdgeDriver();
		
		driver.manage().window().maximize();
		
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		//driver.findElement(By.xpath("//input[@name=\"username\"]")).sendKeys("Admin");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name=\"username\"]"))).sendKeys("Admin");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name=\"password\"]"))).sendKeys("admin123");
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type=\"submit\"]"))).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()=\"PIM\"]"))).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[normalize-space()=\"Employment Status\"]/parent::div[contains(@class,\"oxd-input-group__label-wrapper\")]/following-sibling::div/div[@class=\"oxd-select-wrapper\"]"))).click();

		
		List<WebElement> dropValues = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@role=\"listbox\"]/div/span")));

		
		System.out.println(dropValues.size());
		
		for(WebElement x : dropValues)
		{
			System.out.println(x.getText());
		}
		
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()=\"Full-Time Probation\"]"))).click();
		
		
		
		//driver.close();

	}

}
