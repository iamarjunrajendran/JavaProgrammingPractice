package Day31_Dropdowns;

import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Auto_SuggestionDropDown {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
		
		driver.get("https://www.google.com/");
		 Thread.sleep(5000);
		driver.findElement(By.xpath("//textarea[@jsname=\"yZiJbe\"]")).sendKeys("test");
		
		List<WebElement> drop = driver.findElements(By.xpath("//div[@id=\"Alh6id\"]//ul[@role=\"listbox\"]/li"));
		System.out.println("Search options: "+ drop.size());
		
		
		for(int i = 0; i<drop.size(); i++)
		{
			System.out.println(drop.get(i).getText());
			
			if(drop.get(i).getText().contains("test speed"))
			{
				Thread.sleep(2000);
				drop.get(i).click();
				break;
			}
			
		}
		
		
		
		
	}

}
