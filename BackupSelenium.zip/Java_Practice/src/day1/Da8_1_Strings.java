package day1;

import java.util.Arrays;

public class Da8_1_Strings {

	public static void main(String[] args) {
		
		// We can initialize String as an object too.
		String s="welcome";
		String s1=new String("Welcome"); //-> Alternate
		System.out.println(s);
		System.out.println(s1);
		
		//length() - returns length of the string
				String s3="welcome";
				System.out.println("String Length:"+s3.length());
				
				
		//concat() - join string
				String s1i="welcome";
				String s2i="to java";
				String s3i="programming";
				
				System.out.println("Concat");
				System.out.println(s1i+s2i);
				System.out.println(s1.concat(s2i));
				
				
				System.out.println(s1i+s2i+s3i);
				System.out.println(s1.concat(s2i).concat(s3i));
				
				System.out.println("welcome"+"to java");
				System.out.println("welcome".concat("to java"));//-> little different
				
				
				//trim() - remove spaces right right and left side
				s="   welcome   ";
				System.out.println("Trimming:");
				System.out.println("Before trimming:"+ s.length()); //13
				s1=s.trim();
				System.out.println("After trimming:"+s1.length()); //7
				
				//charAt() - returns a character based on index
				// index starts from 0
				
				s="welcome";
				System.out.println("CharAT");
				System.out.println(s.charAt(3));   //c
				System.out.println(s.charAt(5));  //m 
		
				//contains() - returns true/false
				//check a string is part of the main string
				
				System.out.println("Contains:");
				System.out.println(s.contains("wel"));  //true
				System.out.println(s.contains("Come")); //false-> Due to Case sensitivity
				System.out.println(s.contains("come")); //true
				
				System.out.println(s.contains("welome")); //false
				
				//equals() , equalsIgnoreCase()  - compare 2 strings
				// returns true/false
				
				System.out.println("Equals/Equalsignorecase:");
				String s1A="welcome";
				String s2A="welcome";
				
				System.out.println(s1A.equals(s2A)); // true
				System.out.println(s1A.equals("Welcome"));  //false -> Due to Case sensitivity
				
				System.out.println(s1A.equalsIgnoreCase("Welcome"));  //true
				
				//replace() - replace single character/sequence of characters(string) in a string
				
				System.out.println("Replace:");
				s="welcome to selenium java python python";
				
				System.out.println(s.replace('e','X')); //wXlcomX to sXlXnium java python python
				System.out.println(s.replace("python","C#")); //welcome to selenium java C# C#

				//substring() - extract substring from the main string
				
				System.out.println("Substring:");
				s="welcome";
				
				System.out.println(s.substring(2, 5)); //lco -> In includes the starting index characters but the ending index characters won't include.
				System.out.println(s.substring(1,3)); //el
				
				//toUpperCase()   toLowerCase() - converting case
				System.out.println("To convert the case:");
				s="Welcome";
				
				System.out.println(s.toUpperCase()); //WELCOME  // convert to upper case
				System.out.println(s.toLowerCase()); //welcome // convert to lower case
				
				//split() - split/divide the string in to multiple parts based on delimiter.
				
				s="abc,123@xyz";
				
				String first = s.split(",")[0];
				String second= s.split(",")[1].split("@")[0];
				String third= s.split(",")[1].split("@")[1];
				
				System.out.println(first);
				System.out.println(second);
				System.out.println(third);
				
				//Ex1
				s="abc@xyz";
				
				String a[]=s.split("@");
				System.out.println(a[0]);  //abc
				System.out.println(a[1]); //xyz
				
				
				//Ex2
				s="abc@gmail.com";
				
				String a5[]=s.split("@");
				System.out.println(a5[0]); //abc
				System.out.println(a5[1]); //gmail.com
				
				
				//Ex3  - replace()
				String amount="$15,20,55";       // output :   152055
				System.out.println(amount.replace("$","").replace(",","")); //152055
				
				
				//Ex4
				//s="abc,123@xyz";       // output abc , 123, xyz
				
				String a1[]=s.split(",");   //abc,  123@xyz
				System.out.println(a1[0]);   //abc
				System.out.println(a1[1]); //123@xyz
				
				String a2[]=a1[1].split("@");
				System.out.println(a2[0]); //xyz
				System.out.println(a2[1]); //123
				

				//Ex5
				s="abc 123 xyz";
				String arr[]=s.split(" ");
				System.out.println(Arrays.toString(arr));  //[abc, 123, xyz]
			
				// *  %  ^   &  (   ) - you cannot use as delimiters   
				
				//Just in runtime it process the values as specified without updating the variable
				
				String name="John Kenedy";
				
				//System.out.println(name.contains("john")); //false
				
				//System.out.println(name.toLowerCase().contains("john"));  //true
				
				System.out.println(name.replace('J','j').contains("john"));
				
				
				System.out.println(name);
				
				




	}

}
