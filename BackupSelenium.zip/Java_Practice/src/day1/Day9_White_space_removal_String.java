package day1;

public class Day9_White_space_removal_String {
	
	public static void main(String[] args)
	{
		String s="we l co m e";
		
		s=s.replaceAll(" ", "");
		System.out.println(s);
		String s2= "we l co m e"; 
		s2=s2.replaceAll("\\s",""); //\\s represents the space in the regex.
		
		System.out.println(s2);

	}

}
