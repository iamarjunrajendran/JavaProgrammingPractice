package day1;

public class Day9_Remove_specialCharacters_String {

	public static void main(String[] args) {
		
		String s = "wel&&^^%%*())*come";
		
		s=s.replaceAll("[^A-Za-z0-9]",""); //^ symbol used to specify that exclude rest all than specified
		
		System.out.println(s);
		
		//to remove the certain special characters only
		
		String s2= "Hello +-^ my + - friends ^^^ +!";
		
		s2= s2.replaceAll("[\\-\\+\\^]", "");
        System.out.println(s2);
	}

}
