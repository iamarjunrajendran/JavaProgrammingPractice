package day1;






public class Day7_FindingtheMissingnumber_Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int a[]= new int[5];
		int b[]= new int[5];
		int sum1=0;
		int sum2=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the array inputs A1:");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
		System.out.println("Entered array:"+ Arrays.toString(a));
		
		System.out.println("Please enter the array inputs A2:");
		for(int i=0;i<b.length;i++)
		{
			b[i]=sc.nextInt();
			
		}
		System.out.println("Entered array:"+ Arrays.toString(b));*/
		
		int a[]= {1,2,3,4,5};
		int b[]= {1,2,4,5};
		int sum1=0;
		int sum2=0;
		
		for(int j=0;j<a.length;j++)
		{
			sum1=sum1+a[j];
		}
		
		System.out.println("Sum1:"+sum1);
		
		for(int j=0;j<b.length;j++)
		{
			sum2=sum2+b[j];
		}
		
		System.out.println("Sum2:"+sum2);
		
		int result = sum2-sum1;
		
		System.out.println(Math.abs(result)); //Math.abs for coverting into positive number.
		
	}

}
