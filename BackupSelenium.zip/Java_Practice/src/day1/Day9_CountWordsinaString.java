package day1;

import java.util.Scanner;

public class Day9_CountWordsinaString {
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String source;
		int count=1;
		System.out.println("Enter the text to be checked:");
		source=sc.nextLine();
		sc.close();
		for(int i=0; i<source.length()-1;i++)
		{
			if((source.charAt(i)==' ') && (source.charAt(i+1)!=' '))
			{
				count++;
			}
		}
		
		System.out.println("No.of words in a String:"+count);
	}

}
