package day1;

public class Day6_sumofarrayelements {

	public static void main(String[] args) {
		
		int sum=0;
		int adv_sum=0;
		int a[]= {1,2,3,4,10};
		int even=0;
		int odd=0;
		for(int i=0;i<=a.length-1;i++)
		{
			sum=sum+a[i];
			if(a[i]%2==0) 
			{
				System.out.println(a[i]+" is even");
				even++;
			}
			else 
			{
				System.out.println(a[i]+" is odd");
				odd++;
			}
		}
		
		
		System.out.println("Even:"+even);
		System.out.println("Odd:"+odd);
		System.out.println(sum+" is the sum of elements");
		
		//For each
		for(int x:a)
		{
			adv_sum=adv_sum+x;
		}
		System.out.println(adv_sum);

	}

	
}
