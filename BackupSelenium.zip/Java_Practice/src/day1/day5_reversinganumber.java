package day1;

import java.util.Scanner;

public class day5_reversinganumber {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number:");
		
		
		int act_num=sc.nextInt();
		
		sc.close();

		//It won't support the negative numbers
		
		// Method 1: Arithmetic(% /)
		/*int rev_num=0;
		while(act_num!=0)
		{
			
			rev_num = rev_num * 10 + act_num % 10;
			act_num = act_num/10;
		}*/
		
		// Method 2: Using String buffer class
		/*StringBuffer sb = new StringBuffer(String.valueOf(act_num));
		StringBuffer rev_num= sb.reverse();*/
		

		//Method 3: Using the String Builder class
		StringBuilder sbl = new StringBuilder();
		sbl.append(act_num);
		StringBuilder rev_num= sbl.reverse();
		System.out.println(rev_num);
		

		
		
	}

}
