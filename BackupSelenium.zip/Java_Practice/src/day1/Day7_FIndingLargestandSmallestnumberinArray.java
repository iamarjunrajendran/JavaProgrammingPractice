package day1;



public class Day7_FIndingLargestandSmallestnumberinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {100,789,10,1001};
/*Arrays.sort(a); -> My short version
System.out.println("Smallest:"+a[0]+" Largest:"+a[3]);*/

int max=a[0];
int min=a[0];

for (int i=1;i<a.length;i++)
{
  if(a[i]>max)
  {
	  max=a[i];
  }
  
  if(a[i]<min)
  {
	  min=a[i];
  }
}

System.out.println("Max:"+max + " Min:"+min);

	}

}
