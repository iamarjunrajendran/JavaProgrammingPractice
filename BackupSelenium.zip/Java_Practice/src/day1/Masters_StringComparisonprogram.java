package day1;

import java.util.Scanner;

public class Masters_StringComparisonprogram {

	static void validator(String a,String b) throws StringIndexOutOfBoundsException{
		
		//String str1="abc";
		//String str2="bbc";
		String token="abcbbc";
		
		String Result = a+b;
		
		if(Result.equals(token))
		{
			System.out.println("Match Found");
		}
		else {
			//System.out.println("Not yet");
			
			throw new StringIndexOutOfBoundsException("Match not found yet");
		}
	}

public static void main(String[] args) {
	
	String str1;
	String str2;
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter the username:");
	str1=sc.nextLine();
	System.out.println("Enter the cache:");
	str2=sc.nextLine();
	
	try {
		validator(str1,str2);
	}
	catch (StringIndexOutOfBoundsException e)
	{
		System.out.println(e.getMessage());
	}
		sc.close();
}
	
}
