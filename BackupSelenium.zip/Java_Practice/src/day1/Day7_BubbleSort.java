package day1;

import java.util.Arrays;

public class Day7_BubbleSort {

	public static void main(String[] args) {

		
		int a[]= {5,2,4,1,3};
		
		System.out.println("Before: "+Arrays.toString(a));
		
		for(int i=0;i<a.length-1;i++) // Handles the passes
		{
			for(int j=0;j<a.length-1;j++)
			{
				if(a[j]>a[j+1])
				{
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		
		System.out.println("After: "+Arrays.toString(a));
	}

}
