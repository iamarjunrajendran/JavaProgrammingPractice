package day1;

public class Day5_Palindrome {

	public static void main(String[] args) {
		int num=121;
		int act=121;
		int rev=0;
		
		while(num!=0) {
			rev=rev*10+num%10;
			num=num/10;
			
		}
		System.out.println(rev);
		
		if(rev==act)
		{
			System.out.println("It's palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}

	}

}
