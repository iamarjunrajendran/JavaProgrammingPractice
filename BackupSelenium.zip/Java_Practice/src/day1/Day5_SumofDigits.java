package day1;

public class Day5_SumofDigits {

	public static void main(String[] args) {
		
		int num=1213;
		int ans=0;
		while(num!=0)
		{
			ans=ans+num%10;
			
			num=num/10;
			
		}
		
		System.out.println(ans);

	}

}
