package day1;

public class Day8_HeterogeneousdataClass {

	public static void main(String[] args) {


		//Arrays are something holds the same type of data into that, but we could have the different type of data as well using the Object type Array. It's not recommended though to use it. This is solely for the interview process.
		
		Object a[] = new Object[5];
		
		a[0]= "String";
		a[1]= 2.5;
		a[2]= true;
		a[3]= 'A';
		a[4]= 10;
		
		for(Object x:a)
		{
			System.out.println(x);
		}
		

	}

}
