package day1;



public class Day9_String_Palindrome {

	public static void main(String[] args) {
		String s="MADAM"; //5
		String rev="";
		String rev2="";
    
		//Using Char array and string reversal without using inbuilt methods
		
	char[] a=	s.toCharArray();
     
     //System.out.println(a[2]);
     
     for(int i=s.length()-1;i>=0;i--)
     {
     
    	// System.out.println(a[i]);
    	 rev=rev+a[i];
    	 
     }
System.out.println(rev);

if(s.equals(rev))
{
	System.out.println("Palindrome");
}
else {
	System.out.println("Not Palindrome");
}

//using charat without suing the char array simple way

for(int i=s.length()-1;i>=0;i--)
{

	// System.out.println(a[i]);
	 rev2=rev2+s.charAt(i);
	 
}

if(s.equals(rev2))
{
	System.out.println("Palindrome");
}
else {
	System.out.println("Not Palindrome");
}


}
}




