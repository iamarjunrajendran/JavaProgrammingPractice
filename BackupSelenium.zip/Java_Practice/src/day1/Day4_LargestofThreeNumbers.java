package day1;

public class Day4_LargestofThreeNumbers {

	public static void main(String[] args) {
		
		int a=20,b=40,c=10;
		
		if((a>b) && (a>c))
		{
			System.out.println(a+"is the lasrgest number");
			
				
			
			
		}
		else if(b>a && b>c){
			
			
		System.out.println(b+"is the largest number");
			
		}
		else 
		{
			System.out.println(c+"is the largest number");
		}
		}
			
		
		
}
