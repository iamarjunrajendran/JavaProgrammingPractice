package day1;

public class Day9_CharCountString {
	
	public static void main(String[] args){
		
		String s="Welcome"; //7
		
		int count = 0;
		
		// counting the characters count
		for(int i=0;i<s.length();i++)
		{
			s.charAt(i);
			count++;
		}
		
		System.out.println(count);
		// counting the occurrence of the characters
		String s2="Java is the optimal language";
		int tot= s2.length();
		int occ= s2.replace("a", "").length();
		System.out.println(tot-occ+"is the chatacer occurrence");
		
		
		
	}
}
