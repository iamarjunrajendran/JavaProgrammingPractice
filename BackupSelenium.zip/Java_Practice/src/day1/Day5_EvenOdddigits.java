package day1;

public class Day5_EvenOdddigits {

	public static void main(String[] args) {
		
		int num= 1923;
		int even=0;
		int odd=0;
		
		while(num!=0)
		{
		int rem=num%10; // To extract the last digit individually
		
		if(rem%2==0) {
			System.out.println(rem + " is Even");
			even++;
			
		}
		else {
			System.out.println(rem +" is Odd");
			odd++;
		}
		num=num/10; // To remove the last digit
		}
		
		System.out.println("Even: " +even + " Odd: "+odd);
		
		

	}

}
