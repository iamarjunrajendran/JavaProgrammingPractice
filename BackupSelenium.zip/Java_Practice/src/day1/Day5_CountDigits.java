package day1;

public class Day5_CountDigits {

	public static void main(String[] args) {
		int num=1136;
		
		
		int count=0;
		
		while(num!=0)
		{
			num=num/10;
			count+=1;
			
		}
System.out.println(count);
	}

}
