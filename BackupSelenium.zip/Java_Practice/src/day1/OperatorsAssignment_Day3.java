package day1;

public class OperatorsAssignment_Day3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0;
		int b=10;
		/*a=a+b;
		b=a-b;
		a=a-b;
		System.out.println(a);
		System.out.println(b);*/
		
		//Another different Approach
		
		b=a+b-(a=b);
		System.out.println(a+" "+ b);
				

	}

}
