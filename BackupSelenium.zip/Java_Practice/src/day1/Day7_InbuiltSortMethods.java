package day1;

import java.util.Arrays;
import java.util.Collections;

public class Day7_InbuiltSortMethods {

	public static void main(String[] args) {
		
        int a[]= {5,2,4,1,3};
        
      //Using Parallel sort
		
		System.out.println("Before: "+Arrays.toString(a));
		Arrays.parallelSort(a);
		System.out.println("After parallel sort: "+Arrays.toString(a));
		
		// Using Sort method:
		System.out.println("Before: "+Arrays.toString(a));
		Arrays.sort(a);
		System.out.println("After sort method: "+Arrays.toString(a));
		
		// To reverse the array:
		
		Integer b[]= {5,2,4,1,3}; //To use the collections, derived data type should be used(INTEGER instead of INT)
		System.out.println("Before: "+Arrays.toString(b));
		Arrays.sort(b,Collections.reverseOrder());
		System.out.println("After reverse sort method: "+Arrays.toString(b));
		

	}

}
