package day1;

public class Day5_Assignment {

	public static void main(String[] args) {
		
		int a = 20;
		int b= 50;
		int c= 30;
		String Choice = "Wednesday";
		
		//Largest of two numbers in the ternary operator
		int res=(a>b)?a:b;
		System.out.println(res+" is the largest number");
		
		//Smallest of three numbers
		
		if((a<b)&&(a<c)) {
			
			
			System.out.println(a+" is the smallest number");
			
		}
		else if((b<a)&&(b<c)){
			System.out.println(b+" is the smallest number");
			
		}
		
		else {
			System.out.println(c+" is the smallest number");
			}
		
		
		//switch statement-> Printing the week day number based on the week name
		
		switch(Choice)
		{
			case "Monday": System.out.println(1);break;
			case "Tuesday": System.out.println(2);break;
			case "Wednesday": System.out.println(3);break;
			case "Thursday": System.out.println(4);break;
			case "Friday": System.out.println(5);break;
			case "Saturday": System.out.println(6);break;
			case "Sunday": System.out.println(7);break;
			default: System.out.println("Invalid week name");
		}
		
		// Odd/Even number
		int i=1;
		while(i<=10)
		{
			if(i%2==0)
			{
				System.out.println(i+ " is the even number");
				
			}
			
			else {
				System.out.println(i+ " is the odd number");
			}
			
			i++;
		}

	}

}

