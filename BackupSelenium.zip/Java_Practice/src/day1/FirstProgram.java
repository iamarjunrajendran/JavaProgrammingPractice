package day1;

public class FirstProgram 
{

	public static void main(String[] args) 
	{
		
		
		System.out.println("welcome");
		System.out.println(1+2+3);
		System.out.println("Welcome"+2+"Tourists!");
		
//		System.out.println("Single line comment");
		/*
		 * System.out.println("Single line comment");
		 * System.out.println("Single line comment");
		 * System.out.println("Single line comment");
		 */

	}

}
