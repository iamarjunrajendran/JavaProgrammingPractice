package ArrayProblems;

import java.util.Scanner;

public class Array_FindOddandEvenfromanArray {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] array = new int[5];
		System.out.println("Provide the inputs ");
		for(int i=0;i<array.length;i++)
		{
			array[i]= sc.nextInt();
		}
		

	}

}
