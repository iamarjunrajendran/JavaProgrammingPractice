package ArrayProblems;

import java.util.Arrays;
import java.util.Scanner;

public class Array_2ndLargestElement {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a[]= new int[5];
		
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		Arrays.sort(a);
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		int second = a[3];
		System.out.println(second);

	}

}
