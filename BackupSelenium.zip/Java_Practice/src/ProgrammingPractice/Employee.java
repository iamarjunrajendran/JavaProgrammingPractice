package ProgrammingPractice;

public class Employee{
	
	private int id;
	private String name;
	
	public Employee(int id,String name)
	{
		this.id= id;
		this.name=name;
		
	}
	
	public int getid()
	{
		return id;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String toString() {
		return("Id:"+id + "Name:"+name);
	}
	
}