package ProgrammingPractice;




public class Groupclass{

	public static void main(String[] args) {


		 Group group = new Group(1001);

		        group.addEmployee(new Employee(1, "Vinayak"));
		        group.addEmployee(new Employee(2, "Muruga"));
		        group.addEmployee(new Employee(3, "Muruga"));
		        group.addEmployee(new Employee(4, "Zoya"));
		        group.addEmployee(new Employee(5, "Vaibhav"));

		        System.out.println("Before Sorting:");
		        System.out.println(group.getEmployees());

		        // ✅ Sorting
		        group.sortEmployeesByName();

		        System.out.println("\nAfter Sorting:");
		        System.out.println(group.getEmployees());

	}

}
