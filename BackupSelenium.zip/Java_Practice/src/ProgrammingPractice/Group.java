package ProgrammingPractice;

import java.util.ArrayList;

import java.util.Comparator;

public class Group {

	
	private int groupID;
	private ArrayList<Employee> employees;
	
	public Group(int groupID){
		
		this.groupID = groupID;
		this.employees = new ArrayList<>();
	}

public void addEmployee(Employee e) {
        employees.add(e);
    }

    public int getGroupId() {
        return groupID;
    }

    public ArrayList<Employee> getEmployees() {
        return employees;

    }

 
     public void sortEmployeesByName() {
    	 employees.sort(Comparator.comparing(Employee::getName));
    	 }
}
