package testBase;

import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger; 

public class BaseClass {
	public WebDriver driver;
	public Logger logger;
	public Properties pr;
@BeforeClass
@Parameters({"os","browser"})
public void TestSetup(String OS,String Browser) throws IOException
{
	//Properties
	FileReader file = new FileReader(".//src//test//resources//config.properties");
	pr= new Properties();
	pr.load(file);
	
	logger = LogManager.getLogger(this.getClass());
	
	switch(Browser)
	{
	case"chrome": driver= new ChromeDriver();break;
	case"edge": driver= new EdgeDriver();break;
	case"firefox": driver= new FirefoxDriver();break;
	default: System.out.println("Invalid browser option");return;
	}


driver.manage().deleteAllCookies();

driver.get(pr.getProperty("appURL"));
driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));


}
@AfterClass
public void TestTearDown()
{
driver.close();
}



public String RandomString()
{
	
	String randomString= RandomStringUtils.insecure().nextAlphabetic(5);
	return randomString;
}

public String RandomNumber()
{
	
	String randomNumber= RandomStringUtils.insecure().nextNumeric(10);
	return randomNumber;
	}


public String RandomPassword()
{
	
	String randomPassword= RandomStringUtils.secure().nextAlphanumeric(10);
	return randomPassword;
	}

}