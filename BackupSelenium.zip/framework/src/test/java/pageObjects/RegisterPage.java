package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisterPage extends BasePage {
	
	public RegisterPage(WebDriver driver)
	{
		super(driver);
	}

	
	@FindBy(xpath="//input[@name=\"firstname\"]")
	WebElement inputFirstName;
	
	@FindBy(xpath="//input[@name=\"lastname\"]")
	WebElement inputLastname;
	
	@FindBy(xpath="//input[@name=\"email\"]")
	WebElement inputEmail;
	
	@FindBy(xpath="//input[@name=\"telephone\"]")
	WebElement inputPhone;
	
	@FindBy(xpath="//input[@name=\"password\"]")
	WebElement inputPassword;
	
	@FindBy(xpath="//input[@name=\"confirm\"]")
	WebElement inputConfirm;
	
	@FindBy(xpath="//input[@name=\"agree\"]")
	WebElement inputAgree;
	
	@FindBy(xpath="//input[@value=\"Continue\"]")
	WebElement btnContinue;
	
	@FindBy(xpath="//div[@id=\"content\"]/h1")
	WebElement SuccessMessage;
	
	public void firstName(String fname) {
		inputFirstName.sendKeys(fname);
	}
	
	public void LastName(String Lname) {
		inputLastname.sendKeys(Lname);
	}
	
	
	
	public void Email(String email) {
		inputEmail.sendKeys(email);
	}
	
	public void Phone(String phone) {
		inputPhone.sendKeys(phone);
	}
	
	public void Passowrd(String password) {
		inputPassword.sendKeys(password);
	}
	
	public void confirmmPassowrd(String cnfmPassword) {
		inputConfirm.sendKeys(cnfmPassword);
	}
	
	public void Agree() {
		inputAgree.click();
	}
	
	public void btnContinue() {
		btnContinue.click();
	}
	
	public String getConfirmationMessage()
	{
	
		try {
			
			return(SuccessMessage.getText());
		}
		catch(Exception e)
		{
			return(e.getMessage());
		}
		
	}
}
