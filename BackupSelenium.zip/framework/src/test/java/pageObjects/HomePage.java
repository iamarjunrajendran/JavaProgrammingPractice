package pageObjects;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class HomePage extends BasePage {
	
	public HomePage(WebDriver driver) {
		
		super(driver);
	}
	
	@FindBy(xpath="//span[normalize-space()='My Account']")
	WebElement lnkAccount;

	@FindBy(xpath="//a[normalize-space()='Register']")
    WebElement lnkRegister;
	
	
public void clickMyAccount()
{
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));	
	wait.until(ExpectedConditions.elementToBeClickable(lnkAccount)).click();
	//lnkAccount.click();
}

public void clickRegister()
{
	lnkRegister.click();
	
}

}



