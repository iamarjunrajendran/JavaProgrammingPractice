package testCases;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.RegisterPage;
import testBase.BaseClass;

public class AccountRegistrationTest extends BaseClass{
	




@Test
public void verifyAccountRegistration()
{

	logger.info("***** Starting TC001_AccountRegistrationTest  ****");
	logger.debug("This is a debug log message");
	//HomePage
	try {
HomePage ho = new HomePage(driver);

ho.clickMyAccount();
ho.clickRegister();
logger.info("Clicked on the registration page");
//RegisterPage
logger.info("Navigated to the registration page");
RegisterPage reg = new RegisterPage(driver);
String Password = RandomPassword();
String response = "Your Account Has Been Created!";

reg.firstName(RandomString());
reg.LastName(RandomString());
reg.Email(RandomString()+"@"+RandomString()+".com");
reg.Phone(RandomNumber());
reg.Passowrd(Password);
reg.confirmmPassowrd(Password);
reg.Agree();
reg.btnContinue();
logger.info("Provided details in the registration page and doing the validation");
AssertJUnit.assertEquals(reg.getConfirmationMessage(), response);
	}
	
     catch (Exception e)
		{
			logger.error("Test failed: " + e.getMessage());
			AssertJUnit.fail("Test failed: " + e.getMessage());
		} 

	finally {
		logger.info("******Testcase is completed********");
	}

}






}
